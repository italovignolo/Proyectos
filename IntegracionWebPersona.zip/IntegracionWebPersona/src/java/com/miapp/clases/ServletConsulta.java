/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.miapp.clases;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Insuco
 */
@WebServlet(name = "servlet_controlador", urlPatterns = {"/servlet_controlador"})
public class ServletConsulta extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletConsulta</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ServletConsulta at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String boton_mostrar = request.getParameter("mostrar");
        String boton_eliminar = request.getParameter("Eliminar");
       
        
        if(boton_eliminar != null){
            String id_persona = request.getParameter("id");
            ModelPersona modelo = new ModelPersona();
            int id_p = Integer.parseInt(id_persona);
          ControllerPersona persona = new ControllerPersona();
        ArrayList <ControllerPersona> pers = modelo.getPersonaxxx(id_p);
          modelo.eliminarPersona(id_p);
          
          request.setAttribute("persona", pers);
          request.setAttribute("nombre", persona.getNombre());
          request.setAttribute("id_p", id_p);
          request.getRequestDispatcher("ViewEliminar.jsp").forward(request, response);
        }
        
        if(boton_mostrar != null){
            //crear un objeto de la Clase ControllerPersona y enviarlo a una vista .JSP
            int Id_persona = 5;
            String Nombre = "Italo";
            String Apellido = "Vignolo";
            int Edad = 64;
            ControllerPersona persona = new ControllerPersona(Id_persona, Nombre, Apellido, Edad);
            ModelPersona modelo = new ModelPersona();
            
            //ControllerPersona persona = modelo.getPersona(4);
            ArrayList<ControllerPersona> personas = modelo.getPersonas();
            
            String html = "";
            for(ControllerPersona persona_bd: personas){
                html += "<tr>";
                html += "<td>"+persona_bd.getId_persona()+"</td>";
                html += "<td>"+persona_bd.getNombre()+"</td>";
                html += "<td>"+persona_bd.getApellido()+"</td>";
                html += "<td>"+persona_bd.getEdad()+"</td>";
                html += "</tr>";
            }
            
            modelo.cerrar_conexion();
            //settear Atributos para mostrar en la vista JSP
            request.setAttribute("Id_persona", persona.getId_persona());
            request.setAttribute("Nombre", persona.getNombre());
            request.setAttribute("Apellido", persona.getApellido());
            request.setAttribute("Edad", persona.getEdad());
            request.setAttribute("html", html);
            
            //enviar los atributos a la vista .JSP
            request.getRequestDispatcher("ViewRespuesta.jsp").forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
        String boton_ingresar = request.getParameter("ingresar");
        
        if(boton_ingresar != null){
            String nombre = request.getParameter("Nombre");
            String apellido = request.getParameter("Apellido");
            String edad  = request.getParameter("Edad");
            int edaad = Integer.parseInt(edad);
            ModelPersona modelo =new  ModelPersona();
            ControllerPersona persona = new ControllerPersona();
            modelo.guardarPersona(nombre, apellido, edaad);
            modelo.cerrar_conexion();
            
            request.setAttribute("Id_persona", persona.getId_persona());
            request.setAttribute("Nombre", nombre);
            request.setAttribute("Apellido", apellido);
            request.setAttribute("Edad", edaad);
            request.getRequestDispatcher("ViewAgregar.jsp").forward(request, response);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
