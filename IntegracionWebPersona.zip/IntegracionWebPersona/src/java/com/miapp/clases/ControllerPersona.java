
package com.miapp.clases;


public class ControllerPersona {
    private int Id_persona;
    private String Nombre;
    private String Apellido;
    private int Edad;
    
    public ControllerPersona (){}//utilizar metodos genericos, validaciones
    
    public ControllerPersona(int Id_persona, String Nombre, String Apellido, int Edad){
        this.Id_persona = Id_persona;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Edad = Edad;
    }

    public int getId_persona() {
        return Id_persona;
    }

    public void setId_persona(int Id_persona) {
        this.Id_persona = Id_persona;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    @Override
    public String toString() {
        return "ControllerPersona{" + "Id_persona=" + Id_persona + ", Nombre=" + Nombre + ", Apellido=" + Apellido + ", Edad=" + Edad + '}';
    }
    
    
}
