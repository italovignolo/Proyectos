/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.miapp.clases;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Insuco
 */
@WebServlet(name = "servlet_editar", urlPatterns = {"/servlet_editar"})
public class ServletEditar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletEditar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ServletEditar at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
    ModelPersona modelo = new ModelPersona();
    ArrayList<ControllerPersona> personas = modelo.getPersonas();
    
    String opciones = "";
    for(ControllerPersona persona: personas){
        opciones += "<option value="+persona.getId_persona()+">"+persona.getNombre()+"</option>";
    }
    //cerrar conexion modelo
    modelo.cerrar_conexion();
    //cargar vista
    request.setAttribute("opciones", opciones);
    request.getRequestDispatcher("ViewSeleccionar.jsp").forward(request, response);
    
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        String boton= request.getParameter("boton");
        
        switch (boton){
                case "1": 
                    ModelPersona modelo = new ModelPersona();
                    String Id_Persona = request.getParameter("id_persona");
                    int ID = Integer.parseInt(Id_Persona);
                    ControllerPersona persona = modelo.getPersona(ID);
                    request.setAttribute("Id_persona", persona.getId_persona());
                    request.setAttribute("Nombre", persona.getNombre());
                    request.setAttribute("Apellido", persona.getApellido());
                    request.setAttribute("Edad", persona.getEdad());
                    request.getRequestDispatcher("ViewEditar.jsp").forward(request, response);
                    modelo.cerrar_conexion();
                    break;
                    
                case "2": 
                    ModelPersona modelo2 = new ModelPersona();
                    String Id_p = request.getParameter("Id_persona");
                    String Nombre = request.getParameter("Nombre");
                    String Apellido = request.getParameter("Apellido");
                    String Edad = request.getParameter("Edad");
                    
                    //transformar id_p y edad
                    
                    int Id = Integer.parseInt(Id_p);
                    int Edad_t = Integer.parseInt(Edad);
                    
                    boolean respuesta = modelo2.updatePersona(Id, Nombre, Apellido, Edad_t);
                    //modelo2.cerrar_conexion();
                    try(PrintWriter out = response.getWriter()){
                        if(respuesta){
                            out.println("<script>alert('Persona Actualizada')</script><a href='/IntegracionWebPersona'>Volver</a>");
                        }else{
                            out.println("<script>alert('ERROR! Persona no actualizada)</script><a href='/IntegracionWebPersona'>Volver</a>");
                        }
                    }
                    break;
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
