package com.miapp.clases;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author italo
 */
public class ControlerTabla {
    
    private int N; 
    private String Empresa; private int a2005; private int a2006; private int a2007; private int a2008; private int a2009; 
    private int a2010; private int a2011; private int a2012; private int a2013; private int a2014; private int a2015;
    
    public ControlerTabla(){}
    
    public ControlerTabla(int N, String Empresa, int a2005, int a2006, int a2007, int a2008, int a2009, int a2010, int a2011, int a2012, int a2013, int a2014, int a2015){
        this.N = N;
        this.Empresa = Empresa;
        this.a2005 = a2005;
        this.a2006 = a2006;
        this.a2007 = a2007;
        this.a2008 = a2008;
        this.a2009 = a2009;
        this.a2010 = a2010;
        this.a2011 = a2011;
        this.a2012 = a2012;
        this.a2013 = a2013;
        this.a2014 = a2014;
        this.a2015 = a2015;
    }

    public int getN() {
        return N;
    }

    public void setN(int N) {
        this.N = N;
    }

    public String getEmpresa() {
        return Empresa;
    }

    public void setEmpresa(String Nombre) {
        this.Empresa = Nombre;
    }

    public int getA2005() {
        return a2005;
    }

    public void setA2005(int a2005) {
        this.a2005 = a2005;
    }

    public int getA2006() {
        return a2006;
    }

    public void setA2006(int a2006) {
        this.a2006 = a2006;
    }

    public int getA2007() {
        return a2007;
    }

    public void setA2007(int a2007) {
        this.a2007 = a2007;
    }

    public int getA2008() {
        return a2008;
    }

    public void setA2008(int a2008) {
        this.a2008 = a2008;
    }

    public int getA2009() {
        return a2009;
    }

    public void setA2009(int a2009) {
        this.a2009 = a2009;
    }

    public int getA2010() {
        return a2010;
    }

    public void setA2010(int a2010) {
        this.a2010 = a2010;
    }

    public int getA2011() {
        return a2011;
    }

    public void setA2011(int a2011) {
        this.a2011 = a2011;
    }

    public int getA2012() {
        return a2012;
    }

    public void setA2012(int a2012) {
        this.a2012 = a2012;
    }

    public int getA2013() {
        return a2013;
    }

    public void setA2013(int a2013) {
        this.a2013 = a2013;
    }

    public int getA2014() {
        return a2014;
    }

    public void setA2014(int a2014) {
        this.a2014 = a2014;
    }

    public int getA2015() {
        return a2015;
    }

    public void setA2015(int a2015) {
        this.a2015 = a2015;
    }
    
    
}
