/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

/**
 *
 * @author italo
 */
public abstract class Persona implements Promedios {
    
    protected String Nombre;
    protected String Apellido;
    protected int   rut;
    protected String fecha_nac;
    
}
